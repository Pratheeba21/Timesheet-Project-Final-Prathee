import React, { useState, useEffect } from "react";
import timesheetService from "../services/timesheetService";
import "./ViewTimesheet.css";
import Modal from "react-modal";
import { useAuth } from "../context/AuthContext";

function ViewTimesheet() {
  document.title = "ViewTimesheet | Employee";
  const [timesheets, setTimesheets] = useState([]);
  const [filteredTimesheets, setFilteredTimesheets] = useState([]);
  const [selectedTimesheet, setSelectedTimesheet] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { empId } = useAuth();
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;
  const [searchDate, setSearchDate] = useState("");

  useEffect(() => {
    loadTimesheets();
  }, [empId]);

  const loadTimesheets = async () => {
    try {
      const response = await timesheetService.getTimesheets();
      const employeeTimesheets = response.data.filter(
        (t) => t.emp_id === empId
      );
      setTimesheets(employeeTimesheets);
      setFilteredTimesheets(employeeTimesheets);
    } catch (error) {
      console.error("Error loading timesheets:", error);
    }
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleBoxClick = (timesheet) => {
    setSelectedTimesheet(timesheet);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedTimesheet(null);
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    return `${date.toISOString().split("T")[0]} ${
      date.toTimeString().split(" ")[0]
    }`;
  };

  const handleSearchDate = (e) => {
    setSearchDate(e.target.value);
    if (e.target.value === "") {
      setFilteredTimesheets(timesheets);
    } else {
      const filtered = timesheets.filter((t) =>
        t.date.includes(e.target.value)
      );
      setFilteredTimesheets(filtered);
    }
  };

  const handleShowAll = () => {
    setSearchDate("");
    setFilteredTimesheets(timesheets);
  };

  const renderTimesheetBoxes = () => {
    if (!filteredTimesheets.length) return <p>No entries available</p>;

    const indexOfLast = currentPage * itemsPerPage;
    const indexOfFirst = indexOfLast - itemsPerPage;
    const currentTimesheets = filteredTimesheets.slice(
      indexOfFirst,
      indexOfLast
    );

    return (
      <div className="timesheet-boxes">
        {currentTimesheets.map((entry, idx) => (
          <div
            key={idx}
            className="timesheet-box"
            onClick={() => handleBoxClick(entry)}
          >
            {entry.date}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="view-timesheet-container">
      <h2>Timesheet Entries</h2>
      <div className="search-container">
        <input
          type="date"
          value={searchDate}
          onChange={handleSearchDate}
          className="search-bar"
        />
        <button onClick={handleShowAll} className="show-all-btn">
          Show All
        </button>
      </div>
      {renderTimesheetBoxes()}
      <div className="pagination-controls">
        <button
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
        >
          Previous
        </button>
        {/* <span>
          Page {currentPage} of{" "}
          {Math.ceil(filteredTimesheets.length / itemsPerPage)}
        </span> */}
        <button
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={
            currentPage === Math.ceil(filteredTimesheets.length / itemsPerPage)
          }
        >
          Next
        </button>
      </div>
      {selectedTimesheet && (
        <Modal
          isOpen={isModalOpen}
          onRequestClose={closeModal}
          contentLabel="Timesheet Details"
          className="timesheet-modal"
          overlayClassName="timesheet-modal-overlay"
        >
          <h2>Timesheet Details for {selectedTimesheet.date}</h2>
          <table>
            <tbody>
              <tr>
                <td>Project Name:</td>
                <td>{selectedTimesheet.project_name}</td>
              </tr>
              <tr>
                <td>Start Time:</td>
                <td>{selectedTimesheet.start_time}</td>
              </tr>
              <tr>
                <td>End Time:</td>
                <td>{selectedTimesheet.end_time}</td>
              </tr>
              <tr>
                <td>Total Hours:</td>
                <td>{selectedTimesheet.total_hours}</td>
              </tr>
              <tr>
                <td>Timestamp:</td>
                <td>{formatTimestamp(selectedTimesheet.timestamp)}</td>
              </tr>
              <tr>
                <td>Comments:</td>
                <td>{selectedTimesheet.comments}</td>
              </tr>
              <tr>
                <td>Lead Approval:</td>
                <td>{selectedTimesheet.lead_approval}</td>
              </tr>
              <tr>
                <td>Manager Approval:</td>
                <td>{selectedTimesheet.manager_approval}</td>
              </tr>
            </tbody>
          </table>
          <button onClick={closeModal} className="close-modal-btn">
            Close
          </button>
        </Modal>
      )}
    </div>
  );
}

export default ViewTimesheet;
