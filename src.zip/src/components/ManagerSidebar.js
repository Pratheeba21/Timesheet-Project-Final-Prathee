import React from "react";
import {
  FaHome,
  FaListAlt,
  FaSignOutAlt,
  FaProjectDiagram,
  FaUsers, // Import new icon
} from "react-icons/fa";
import "./ManagerSidebar.css";
import companyLogo from "../assets/company-logo.png"; // Import the company logo image

const ManagerSidebar = ({ setActiveComponent }) => {
  const handleLogout = () => {
    // Clear the stored active component when logging out
    localStorage.removeItem("managerActiveComponent");
    localStorage.removeItem("token");
    localStorage.removeItem("empId");
    window.location.href = "/login";
  };

  return (
    <div className="manager-sidebar">
      <img src={companyLogo} alt="Company Logo" className="company-logo" />{" "}
      {/* Company logo */}
      <h2>Manager Dashboard</h2>
      <ul>
        <li onClick={() => setActiveComponent("home")}>
          <FaHome className="icon" /> Dashboard
        </li>
        <li onClick={() => setActiveComponent("view-timesheet")}>
          <FaListAlt className="icon" /> View Timesheet
        </li>
        <li onClick={() => setActiveComponent("add-project")}>
          <FaProjectDiagram className="icon" /> Add Project
        </li>
        <li onClick={() => setActiveComponent("employee-info")}>
          {" "}
          {/* New item for EmployeeInfo */}
          <FaUsers className="icon" /> Employee Info
        </li>
        <li onClick={handleLogout}>
          <FaSignOutAlt className="icon" /> Logout
        </li>
      </ul>
    </div>
  );
};

export default ManagerSidebar;
