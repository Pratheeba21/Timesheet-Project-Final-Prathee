import React, { useState, useEffect } from "react";
import LeadSidebar from "./LeadSidebar";
import Home from "./Home";
import LeadPage from "./LeadPage";
import LeadAddModule from "./LeadAddModule";
import EmployeeInfo from "./EmployeeInfo";
import "./LeadDashboard.css";

const LeadDashboard = () => {
  document.title = "Dashboard | Lead";

  const [activeComponent, setActiveComponent] = useState(() => {
    return localStorage.getItem("leadActiveComponent") || "home";
  });

  useEffect(() => {
    localStorage.setItem("leadActiveComponent", activeComponent);
  }, [activeComponent]);

  const renderContent = () => {
    switch (activeComponent) {
      case "home":
        return <Home />;
      case "view-timesheet":
        return <LeadPage />;
      case "add-module":
        return <LeadAddModule />;
      case "employee-info":
        return <EmployeeInfo />;
      default:
        return <Home />;
    }
  };

  return (
    <div className="lead-dashboard">
      <LeadSidebar setActiveComponent={setActiveComponent} />
      <div className="lead-content">{renderContent()}</div>
    </div>
  );
};

export default LeadDashboard;
