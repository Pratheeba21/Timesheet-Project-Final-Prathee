import React, { useEffect, useState } from "react";
import axios from "axios";
import "./ManagerPage.css";
import { FaSignOutAlt } from "react-icons/fa";

const ManagerPage = () => {
  document.title = "View Timesheet | Manager";
  const [timesheets, setTimesheets] = useState([]);
  const [dates, setDates] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [popupData, setPopupData] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [currentPopupPage, setCurrentPopupPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1); // For main page pagination
  const itemsPerPage = 16; // Number of dates per page on the main page
  const itemsPerPopupPage = 6;

  useEffect(() => {
    fetchTimesheets();
  }, []);

  useEffect(() => {
    if (searchQuery === "") {
      setDates(Array.from(new Set(timesheets.map((t) => t.date))));
    } else {
      setDates(
        Array.from(
          new Set(
            timesheets
              .filter((t) => t.date.includes(searchQuery))
              .map((t) => t.date)
          )
        )
      );
    }
  }, [searchQuery, timesheets]);

  const fetchTimesheets = async () => {
    try {
      const response = await axios.get(
        "http://localhost:8000/api/manager-timesheets/"
      );
      const sortedTimesheets = response.data.sort(
        (a, b) => new Date(b.timestamp) - new Date(a.timestamp)
      );
      setTimesheets(sortedTimesheets);
      setDates(Array.from(new Set(sortedTimesheets.map((t) => t.date))));
    } catch (error) {
      console.error("Error fetching timesheets:", error);
    }
  };

  const handleDateClick = (date) => {
    setSelectedDate(date);
    const dataForDate = timesheets.filter((t) => t.date === date);
    setPopupData(dataForDate);
    setShowPopup(true);
    setCurrentPopupPage(1);
  };

  const handleApproval = async (timesheetId, approvalStatus) => {
    try {
      await axios.put(
        `http://localhost:8000/api/manager-timesheets/${timesheetId}/`,
        { manager_approval: approvalStatus }
      );
      setPopupData((prevData) =>
        prevData.map((item) =>
          item.id === timesheetId
            ? { ...item, manager_approval: approvalStatus }
            : item
        )
      );
    } catch (error) {
      console.error("Error updating timesheet:", error);
    }
  };

  const handlePopupPageChange = (pageNumber) => {
    setCurrentPopupPage(pageNumber);
  };

  const handleMainPageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleClosePopup = () => {
    setShowPopup(false);
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    return `${date.toISOString().split("T")[0]} ${
      date.toTimeString().split(" ")[0]
    }`;
  };

  const renderPopupCards = () => {
    if (!popupData.length) return <p>No timesheet details available</p>;

    const indexOfLast = currentPopupPage * itemsPerPopupPage;
    const indexOfFirst = indexOfLast - itemsPerPopupPage;
    const currentPopupData = popupData.slice(indexOfFirst, indexOfLast);

    return (
      <div className="manager-popup-content">
        {currentPopupData.map((timesheet) => (
          <div className="manager-card" key={timesheet.id}>
            <p>
              <strong>Employee ID:</strong> {timesheet.emp_id || "N/A"}
            </p>
            <p>
              <strong>Employee Name:</strong> {timesheet.emp_name || "N/A"}
            </p>
            <p>
              <strong>Project Name:</strong> {timesheet.project_name}
            </p>
            <p>
              <strong>Start Time:</strong> {timesheet.start_time}
            </p>
            <p>
              <strong>End Time:</strong> {timesheet.end_time}
            </p>
            <p>
              <strong>Total Hours:</strong> {timesheet.total_hours}
            </p>
            <p>
              <strong>Timestamp:</strong> {formatTimestamp(timesheet.timestamp)}
            </p>
            <p>
              <strong>Comments:</strong> {timesheet.comments}
            </p>
            <p>
              <strong>Lead Approval:</strong>{" "}
              {timesheet.lead_approval || "pending"}
            </p>
            <p>
              <strong>Manager Approval:</strong>{" "}
              {timesheet.manager_approval || "pending"}
            </p>
            {timesheet.manager_approval === "pending" && (
              <div className="manager-approval-buttons">
                <button
                  className="manager-approve-button"
                  onClick={() => handleApproval(timesheet.id, "approved")}
                >
                  Approve
                </button>
                <button
                  className="manager-reject-button"
                  onClick={() => handleApproval(timesheet.id, "rejected")}
                >
                  Reject
                </button>
              </div>
            )}
          </div>
        ))}
        <div className="manager-popup-controls">
          <button
            onClick={() => handlePopupPageChange(currentPopupPage - 1)}
            disabled={currentPopupPage === 1}
          >
            &lt;
          </button>
          <span>
            Page {currentPopupPage} of{" "}
            {Math.ceil(popupData.length / itemsPerPopupPage)}
          </span>
          <button
            onClick={() => handlePopupPageChange(currentPopupPage + 1)}
            disabled={
              currentPopupPage ===
              Math.ceil(popupData.length / itemsPerPopupPage)
            }
          >
            &gt;
          </button>
        </div>
      </div>
    );
  };

  const renderDateGrid = () => {
    const indexOfLastDate = currentPage * itemsPerPage;
    const indexOfFirstDate = indexOfLastDate - itemsPerPage;
    const currentDates = dates.slice(indexOfFirstDate, indexOfLastDate);

    return (
      <>
        <div className="manager-date-grid">
          {currentDates.map((date, index) => (
            <div
              className="manager-date-box"
              key={index}
              onClick={() => handleDateClick(date)}
            >
              {date}
            </div>
          ))}
        </div>
        <div className="manager-main-pagination">
          <button
            onClick={() => handleMainPageChange(currentPage - 1)}
            disabled={currentPage === 1}
          >
            Previous
          </button>
          {/* <span>
            Page {currentPage} of {Math.ceil(dates.length / itemsPerPage)}
          </span> */}
          <button
            onClick={() => handleMainPageChange(currentPage + 1)}
            disabled={currentPage === Math.ceil(dates.length / itemsPerPage)}
          >
            Next
          </button>
        </div>
      </>
    );
  };

  return (
    <div className="manager-content">
      <div className="manager-inner-content">
        <h1>Hello, Manager</h1>
        <div className="search-container">
          <input
            type="date"
            placeholder="Search by date"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-bar"
          />
          <button className="show-all-btn" onClick={() => setSearchQuery("")}>
            Show All
          </button>
        </div>
        {renderDateGrid()}
        {showPopup && (
          <div className="manager-popup">
            <button className="manager-popup-close" onClick={handleClosePopup}>
              X
            </button>
            {renderPopupCards()}
          </div>
        )}
      </div>
    </div>
  );
};

export default ManagerPage;
