import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./EmployeeDetails.css";

const EmployeeDetails = () => {
  document.title = "Employee Details | HR";
  const [employees, setEmployees] = useState([]);
  const [searchQuery, setSearchQuery] = useState(""); // State for search query
  const [selectedEmpId, setSelectedEmpId] = useState(null);
  const [timesheets, setTimesheets] = useState([]);
  const [filteredTimesheets, setFilteredTimesheets] = useState([]);
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const employeesPerPage = 20; // 4 columns * 6 rows = 24 boxes

  const navigate = useNavigate();

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const response = await axios.get("/api/employees");
        setEmployees(response.data);
      } catch (error) {
        setError("Error fetching employee data. Please try again later.");
        console.error("Error fetching employees:", error);
      }
    };

    fetchEmployees();
  }, []);

  const handleEmpClick = async (empId) => {
    setSelectedEmpId(empId);
    setLoading(true);
    setError(null);

    try {
      const response = await axios.get(`/api/hr-timesheets/${empId}`);
      const data = response.data;
      setTimesheets(data);
      filterTimesheets(data, currentYear);
    } catch (error) {
      setError("Error fetching timesheets. Please try again later.");
      console.error("Error fetching timesheets:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (timesheets.length > 0) {
      filterTimesheets(timesheets, currentYear);
    }
  }, [currentYear, timesheets]);

  const filterTimesheets = (data, year) => {
    const filtered = data.filter((timesheet) => {
      const date = new Date(timesheet.date);
      return date.getFullYear() === year;
    });
    setFilteredTimesheets(filtered);
  };

  const calculateMonthlySalary = (month) => {
    const daysInMonth = new Date(currentYear, month + 1, 0).getDate();
    const workingDays = [...Array(daysInMonth).keys()]
      .map((day) => new Date(currentYear, month, day + 1))
      .filter((date) => date.getDay() !== 0).length;

    const uniqueDaysWithTimesheets = new Set(
      filteredTimesheets
        .filter((timesheet) => new Date(timesheet.date).getMonth() === month)
        .map(
          (timesheet) => new Date(timesheet.date).toISOString().split("T")[0]
        )
    );

    const leaveDays = workingDays - uniqueDaysWithTimesheets.size;
    const totalHours = filteredTimesheets
      .filter((timesheet) => new Date(timesheet.date).getMonth() === month)
      .reduce((acc, timesheet) => acc + parseFloat(timesheet.total_hours), 0);
    const salary = totalHours * 200;

    return { month, salary };
  };

  const handlePrevYear = () => {
    setCurrentYear((prevYear) => prevYear - 1);
  };

  const handleNextYear = () => {
    setCurrentYear((prevYear) => prevYear + 1);
  };

  const closePopup = () => {
    setSelectedEmpId(null);
    setTimesheets([]);
    setFilteredTimesheets([]);
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const filteredEmployees = employees.filter((employee) =>
    employee.emp_id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Pagination logic
  const indexOfLastEmployee = currentPage * employeesPerPage;
  const indexOfFirstEmployee = indexOfLastEmployee - employeesPerPage;
  const currentEmployees = filteredEmployees.slice(
    indexOfFirstEmployee,
    indexOfLastEmployee
  );
  const totalPages = Math.ceil(filteredEmployees.length / employeesPerPage);

  return (
    <div className="employee-details-container">
      <h2>Employee Salary Details</h2>
      <div className="search-bar-container">
        <input
          type="text"
          placeholder="Search Employee ID..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="search-bar"
        />
        <span className="search-icon">🔍</span> {/* Simple search icon */}
      </div>

      <div className="employee-grid">
        {currentEmployees.map((employee) => (
          <div
            key={employee.emp_id}
            className="employee-box"
            onClick={() => handleEmpClick(employee.emp_id)}
          >
            {employee.emp_id}
          </div>
        ))}
      </div>
      <div className="pagination">
        <button
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
        >
          Previous
        </button>
        <button
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
        >
          Next
        </button>
      </div>

      {selectedEmpId && (
        <div className="popup-overlay" onClick={closePopup}>
          <div className="ppopup-content" onClick={(e) => e.stopPropagation()}>
            <h3>Salary Details for Employee {selectedEmpId}</h3>
            <div className="month-navigation">
              <button
                className="previous-month-button"
                onClick={handlePrevYear}
                disabled={loading}
              >
                Previous Year
              </button>
              <span>{currentYear}</span>
              <button
                className="next-month-button"
                onClick={handleNextYear}
                disabled={loading}
              >
                Next Year
              </button>
            </div>
            {loading ? (
              <p>Loading...</p>
            ) : error ? (
              <p className="error-message">{error}</p>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>Month</th>
                    <th>Salary (₹)</th>
                  </tr>
                </thead>
                <tbody>
                  {[...Array(12).keys()].map((month) => {
                    const { salary } = calculateMonthlySalary(month);
                    return (
                      <tr key={month}>
                        <td>
                          {new Date(currentYear, month).toLocaleString(
                            "default",
                            { month: "long" }
                          )}
                        </td>
                        <td>₹{salary.toFixed(2)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
            <br></br>
            <button className="close-popup-button" onClick={closePopup}>
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeeDetails;
