import React from "react";
import {
  FaHome,
  FaUsers,
  FaSignOutAlt,
  FaClipboardList,
  FaDollarSign,
} from "react-icons/fa";
import "./HRSidebar.css"; // Use the HRSidebar.css for styling
import companyLogo from "../assets/company-logo.png"; // Import the company logo image

const HRSidebar = ({ setActiveComponent }) => {
  const handleLogout = () => {
    // Clear the stored active component when logging out
    localStorage.removeItem("hrActiveComponent");
    localStorage.removeItem("token");
    localStorage.removeItem("empId");
    window.location.href = "/login";
  };

  return (
    <div className="hr-sidebar">
      <img src={companyLogo} alt="Company Logo" className="company-logo" />{" "}
      {/* Company logo */}
      <h2>HR Dashboard</h2>
      <ul>
        <li onClick={() => setActiveComponent("home")}>
          <FaHome className="icon" /> Dashboard
        </li>
        <li onClick={() => setActiveComponent("employee-details")}>
          <FaDollarSign className="icon" /> Salary Details
        </li>
        <li onClick={() => setActiveComponent("employee-timesheet-details")}>
          <FaClipboardList className="icon" /> Employee Timesheet
        </li>
        <li onClick={() => setActiveComponent("employee-info")}>
          <FaUsers className="icon" /> Employee Info
        </li>

        <li onClick={handleLogout}>
          <FaSignOutAlt className="icon" /> Logout
        </li>
      </ul>
    </div>
  );
};

export default HRSidebar;
