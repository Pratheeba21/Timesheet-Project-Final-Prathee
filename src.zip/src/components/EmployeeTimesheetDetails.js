import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./EmployeeTimesheetDetails.css";

const EmployeeTimesheetDetails = () => {
  const [employees, setEmployees] = useState([]);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);
  const [timesheets, setTimesheets] = useState([]);
  const [filteredTimesheets, setFilteredTimesheets] = useState([]);
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showPopup, setShowPopup] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState(""); // New state for search query
  const itemsPerPage = 20; // 4 boxes horizontally * 5 boxes vertically

  const navigate = useNavigate();

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const response = await axios.get("/api/employees/");
        setEmployees(response.data);
      } catch (error) {
        console.error("Error fetching employees:", error);
      }
    };

    fetchEmployees();
  }, []);

  useEffect(() => {
    if (selectedEmployeeId) {
      const fetchTimesheets = async () => {
        setLoading(true);
        setError(null);
        try {
          const response = await axios.get(
            `/api/hr-timesheets/${selectedEmployeeId}`,
            {
              params: {
                month: currentMonth + 1,
                year: currentYear,
              },
            }
          );
          const data = response.data;
          setTimesheets(data);
          filterTimesheets(data);
        } catch (error) {
          setError("Error fetching timesheets. Please try again later.");
          console.error("Error fetching timesheets:", error);
        } finally {
          setLoading(false);
        }
      };

      fetchTimesheets();
    }
  }, [selectedEmployeeId, currentMonth, currentYear]);

  const filterTimesheets = (data) => {
    const filtered = data.filter((timesheet) => {
      const date = new Date(timesheet.date);
      return (
        date.getMonth() === currentMonth && date.getFullYear() === currentYear
      );
    });
    setFilteredTimesheets(filtered);
  };

  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((prevYear) => prevYear - 1);
    } else {
      setCurrentMonth((prevMonth) => prevMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((prevYear) => prevYear + 1);
    } else {
      setCurrentMonth((prevMonth) => prevMonth + 1);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("default", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    });
  };

  const openPopup = (employeeId) => {
    setSelectedEmployeeId(employeeId);
    setShowPopup(true);
  };

  const closePopup = () => {
    setShowPopup(false);
    setSelectedEmployeeId(null);
  };

  const calculateDays = () => {
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const workingDays = [...Array(daysInMonth).keys()]
      .map((day) => new Date(currentYear, currentMonth, day + 1))
      .filter((date) => date.getDay() !== 0).length;

    const uniqueDaysWithTimesheets = new Set(
      filteredTimesheets.map(
        (timesheet) => new Date(timesheet.date).toISOString().split("T")[0]
      )
    );

    const isCurrentMonth =
      currentMonth === new Date().getMonth() &&
      currentYear === new Date().getFullYear();

    const leaveDays = isCurrentMonth
      ? new Date().getDate() - uniqueDaysWithTimesheets.size
      : workingDays - uniqueDaysWithTimesheets.size;

    return { workingDays, leaveDays };
  };

  const { workingDays, leaveDays } = calculateDays();

  // Pagination logic
  const indexOfLastEmployee = currentPage * itemsPerPage;
  const indexOfFirstEmployee = indexOfLastEmployee - itemsPerPage;
  const currentEmployees = employees
    .filter((employee) =>
      employee.emp_id.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .slice(indexOfFirstEmployee, indexOfLastEmployee);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const totalPages = Math.ceil(
    employees.filter((employee) =>
      employee.emp_id.toLowerCase().includes(searchQuery.toLowerCase())
    ).length / itemsPerPage
  );

  return (
    <div className="timesheet-details-container">
      <h2>Employee Timesheet Details</h2>
      <div className="search-bar-container">
        <input
          type="text"
          placeholder="Search Employee ID..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="search-bar"
        />
        <span className="search-icon">🔍</span> {/* Simple search icon */}
      </div>

      <div className="employee-grid">
        {currentEmployees.map((employee) => (
          <div
            key={employee.emp_id}
            className="employee-box"
            onClick={() => openPopup(employee.emp_id)}
          >
            {employee.emp_id}
          </div>
        ))}
      </div>
      <div className="pagination">
        <button
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
        >
          Previous
        </button>
        <button
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
        >
          Next
        </button>
      </div>
      {showPopup && (
        <div className="popup-overlay">
          <div className="popupp-content">
            <h2>Timesheet Details for Employee {selectedEmployeeId}</h2>
            <div className="month-navigation">
              <button
                className="previous-month-button"
                onClick={handlePrevMonth}
                disabled={loading}
              >
                Previous Month
              </button>
              <span>
                {new Date(currentYear, currentMonth).toLocaleString("default", {
                  month: "long",
                })}{" "}
                {currentYear}
              </span>
              <button
                className="next-month-button"
                onClick={handleNextMonth}
                disabled={loading}
              >
                Next Month
              </button>
            </div>
            <div className="days-info">
              <span className="working-days">Working Days: {workingDays}</span>
              <span className="leave-days">Leave Days: {leaveDays}</span>
            </div>
            {loading ? (
              <p>Loading...</p>
            ) : error ? (
              <p className="error-message">{error}</p>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                    <th>Total Hours</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTimesheets.length > 0 ? (
                    filteredTimesheets.map((timesheet) => (
                      <tr key={timesheet.id}>
                        <td>{formatDate(timesheet.date)}</td>
                        <td>{timesheet.start_time}</td>
                        <td>{timesheet.end_time}</td>
                        <td>{timesheet.total_hours}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="4">
                        No timesheets available for this month.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            )}
            <br />
            <button className="close-popup-button" onClick={closePopup}>
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeeTimesheetDetails;
