import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { FaHome, FaEdit, FaListAlt, FaSignOutAlt } from "react-icons/fa"; // Import icons
import "./Sidebar.css";
import companyLogo from "../assets/company-logo.png"; // Import the company logo image

const Sidebar = () => {
  const { empId, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="sidebar">
      <div className="employee-info">
        <img src={companyLogo} alt="Company Logo" className="companyy-logo" /> {/* Company logo */}
        <h3>Employee ID: {empId}</h3>
      </div>
      <ul>
        <li>
          <Link to="/dashboard" className="sidebar-link">
            <FaHome className="icon" /> Dashboard
          </Link>
        </li>
        <li>
          <Link to="/update-timesheet" className="sidebar-link">
            <FaEdit className="icon" /> Update Timesheet
          </Link>
        </li>
        <li>
          <Link to="/view-timesheet" className="sidebar-link">
            <FaListAlt className="icon" /> View Timesheet
          </Link>
        </li>
      </ul>
      <div className="employee-info">
        <button className="logout-button" onClick={handleLogout}>
          <FaSignOutAlt /> Logout
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
