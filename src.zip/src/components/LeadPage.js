import React, { useEffect, useState } from "react";
import axios from "axios";
import "./LeadPage.css";

const LeadPage = () => {
  document.title = "ViewTimesheet | Lead";
  const [timesheets, setTimesheets] = useState([]);
  const [dates, setDates] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [popupData, setPopupData] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [currentPopupPage, setCurrentPopupPage] = useState(1);
  const [currentMainPage, setCurrentMainPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const itemsPerPopupPage = 6;
  const itemsPerMainPage = 16;

  useEffect(() => {
    fetchTimesheets();
  }, []);

  useEffect(() => {
    if (searchQuery === "") {
      setDates(Array.from(new Set(timesheets.map((t) => t.date))));
    } else {
      setDates(
        Array.from(
          new Set(
            timesheets
              .filter((t) => t.date.includes(searchQuery))
              .map((t) => t.date)
          )
        )
      );
    }
    setCurrentMainPage(1); // Reset to the first page on search
  }, [searchQuery, timesheets]);

  const fetchTimesheets = async () => {
    try {
      const response = await axios.get(
        "http://localhost:8000/api/lead-timesheets/"
      );
      const sortedTimesheets = response.data.sort(
        (a, b) => new Date(b.timestamp) - new Date(a.timestamp)
      );
      setTimesheets(sortedTimesheets);

      // Extract unique dates
      setDates(Array.from(new Set(sortedTimesheets.map((t) => t.date))));
    } catch (error) {
      console.error("Error fetching timesheets:", error);
    }
  };

  const handleDateClick = (date) => {
    setSelectedDate(date);
    const dataForDate = timesheets.filter((t) => t.date === date);
    setPopupData(dataForDate);
    setShowPopup(true);
    setCurrentPopupPage(1);
  };

  const handleApproval = async (timesheetId, approvalStatus) => {
    try {
      await axios.put(
        `http://localhost:8000/api/lead-timesheets/${timesheetId}/`,
        {
          lead_approval: approvalStatus,
        }
      );

      setPopupData((prevData) =>
        prevData.map((item) =>
          item.id === timesheetId
            ? { ...item, lead_approval: approvalStatus }
            : item
        )
      );
    } catch (error) {
      console.error("Error updating timesheet:", error);
    }
  };

  const handlePopupPageChange = (pageNumber) => {
    setCurrentPopupPage(pageNumber);
  };

  const handleMainPageChange = (pageNumber) => {
    setCurrentMainPage(pageNumber);
  };

  const handleClosePopup = () => {
    setShowPopup(false);
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    return `${date.toISOString().split("T")[0]} ${
      date.toTimeString().split(" ")[0]
    }`;
  };

  const renderPopupCards = () => {
    if (!popupData.length) return <p>No timesheet details available</p>;

    const indexOfLast = currentPopupPage * itemsPerPopupPage;
    const indexOfFirst = indexOfLast - itemsPerPopupPage;
    const currentPopupData = popupData.slice(indexOfFirst, indexOfLast);

    return (
      <div className="lead-popup-content">
        {currentPopupData.map((timesheet) => (
          <div className="lead-card" key={timesheet.id}>
            <p>
              <strong>Employee ID:</strong> {timesheet.emp_id || "N/A"}
            </p>
            <p>
              <strong>Employee Name:</strong> {timesheet.emp_name || "N/A"}
            </p>
            <p>
              <strong>Project Name:</strong> {timesheet.project_name}
            </p>
            <p>
              <strong>Start Time:</strong> {timesheet.start_time}
            </p>
            <p>
              <strong>End Time:</strong> {timesheet.end_time}
            </p>
            <p>
              <strong>Total Hours:</strong> {timesheet.total_hours}
            </p>
            <p>
              <strong>Timestamp:</strong> {formatTimestamp(timesheet.timestamp)}
            </p>
            <p>
              <strong>Comments:</strong> {timesheet.comments}
            </p>
            <p>
              <strong>Lead Approval:</strong>{" "}
              {timesheet.lead_approval || "pending"}
            </p>
            {timesheet.lead_approval === "pending" && (
              <div className="lead-approval-buttons">
                <button
                  className="lead-approve-button"
                  onClick={() => handleApproval(timesheet.id, "approved")}
                >
                  Approve
                </button>
                <button
                  className="lead-reject-button"
                  onClick={() => handleApproval(timesheet.id, "rejected")}
                >
                  Reject
                </button>
              </div>
            )}
          </div>
        ))}
        <div className="lead-popup-controls">
          <button
            onClick={() => handlePopupPageChange(currentPopupPage - 1)}
            disabled={currentPopupPage === 1}
          >
            &lt;
          </button>
          <span>
            Page {currentPopupPage} of{" "}
            {Math.ceil(popupData.length / itemsPerPopupPage)}
          </span>
          <button
            onClick={() => handlePopupPageChange(currentPopupPage + 1)}
            disabled={
              currentPopupPage ===
              Math.ceil(popupData.length / itemsPerPopupPage)
            }
          >
            &gt;
          </button>
        </div>
      </div>
    );
  };

  const renderMainPageDates = () => {
    const indexOfLast = currentMainPage * itemsPerMainPage;
    const indexOfFirst = indexOfLast - itemsPerMainPage;
    const currentDates = dates.slice(indexOfFirst, indexOfLast);

    return currentDates.map((date, index) => (
      <div
        className="lead-date-box"
        key={index}
        onClick={() => handleDateClick(date)}
      >
        {date}
      </div>
    ));
  };

  return (
    <div className="lead-content">
      <div className="lead-inner-content">
        <h1>Hello, Lead</h1>
        <div className="search-container">
          <input
            type="date"
            placeholder="Search by date"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-bar"
          />
          <button className="show-all-btn" onClick={() => setSearchQuery("")}>
            Show All
          </button>
        </div>
        <div className="lead-date-grid">{renderMainPageDates()}</div>
        <div className="lead-main-pagination">
          <button
            onClick={() => handleMainPageChange(currentMainPage - 1)}
            disabled={currentMainPage === 1}
          >
            Previous
          </button>
          {/* <span>
            Page {currentMainPage} of{" "}
            {Math.ceil(dates.length / itemsPerMainPage)}
          </span> */}
          <button
            onClick={() => handleMainPageChange(currentMainPage + 1)}
            disabled={
              currentMainPage === Math.ceil(dates.length / itemsPerMainPage)
            }
          >
            Next
          </button>
        </div>
        {showPopup && (
          <div className="lead-popup">
            <button className="lead-popup-close" onClick={handleClosePopup}>
              X
            </button>
            {renderPopupCards()}
          </div>
        )}
      </div>
    </div>
  );
};

export default LeadPage;
