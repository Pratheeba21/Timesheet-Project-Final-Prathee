import React from "react";
import {
  FaHome,
  FaListAlt,
  FaSignOutAlt,
  FaPlusSquare,
  FaUsers,
} from "react-icons/fa";
import "./LeadSidebar.css";
import companyLogo from "../assets/company-logo.png";

const LeadSidebar = ({ setActiveComponent }) => {
  const handleLogout = () => {
    localStorage.removeItem("leadActiveComponent");
    localStorage.removeItem("token");
    localStorage.removeItem("empId");
    window.location.href = "/login";
  };

  return (
    <div className="lead-sidebar">
      <img src={companyLogo} alt="Company Logo" className="company-logo" />
      <h2>Lead Dashboard</h2>
      <ul>
        <li onClick={() => setActiveComponent("home")}>
          <FaHome className="icon" /> Dashboard
        </li>
        <li onClick={() => setActiveComponent("view-timesheet")}>
          <FaListAlt className="icon" /> View Timesheet
        </li>
        <li onClick={() => setActiveComponent("add-module")}>
          <FaPlusSquare className="icon" /> Add Module
        </li>
        <li onClick={() => setActiveComponent("employee-info")}>
          <FaUsers className="icon" /> Employee Info
        </li>
        <li onClick={handleLogout}>
          <FaSignOutAlt className="icon" /> Logout
        </li>
      </ul>
    </div>
  );
};

export default LeadSidebar;
