import React, { useState, useEffect } from "react";
import axios from "axios";
import "./ManagerAddProject.css";

axios.defaults.baseURL = "http://localhost:8000"; // Backend URL

const ManagerAddProject = () => {
  document.title = "Manager | Add Project";
  const [employees, setEmployees] = useState([]);
  const [projects, setProjects] = useState([]);
  const [filteredEmployees, setFilteredEmployees] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedEmpId, setSelectedEmpId] = useState("");
  const [projectName, setProjectName] = useState("");
  const [showPopup, setShowPopup] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6; // For 3 columns x 2 rows

  useEffect(() => {
    // Fetch employees data
    axios
      .get("/api/employees/")
      .then((response) => {
        setEmployees(response.data);
        setFilteredEmployees(response.data);
      })
      .catch((error) => {
        console.error("Error fetching employees:", error);
      });

    // Fetch projects data
    axios
      .get("/api/projects/")
      .then((response) => {
        setProjects(response.data);
      })
      .catch((error) => {
        console.error("Error fetching projects:", error);
      });
  }, []);

  useEffect(() => {
    setFilteredEmployees(
      employees.filter((employee) =>
        employee.emp_id.toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
    setCurrentPage(1);
  }, [searchTerm, employees]);

  const handleAddProject = () => {
    const data = {
      emp_id: selectedEmpId,
      project_name: projectName,
    };

    console.log("Data to be sent:", data);

    axios
      .post("/api/projects/", data, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        alert("Project added successfully!");
        closePopup();
      })
      .catch((error) => {
        alert("Project added successfully!");
        closePopup();
      });
  };

  const closePopup = () => {
    setShowPopup(false);
    setSelectedEmpId("");
    setProjectName("");
  };

  const getProjectName = (empId) => {
    const project = projects.find((project) => project.employee_id === empId);
    return project ? project.project_name : "Not Assigned";
  };

  const handleOpenPopup = (empId) => {
    const projectName = getProjectName(empId);
    if (projectName !== "Not Assigned") {
      alert("Project already assigned to this employee");
      return;
    }
    setSelectedEmpId(empId);
    setShowPopup(true);
  };

  // Pagination logic
  const indexOfLastEmployee = currentPage * itemsPerPage;
  const indexOfFirstEmployee = indexOfLastEmployee - itemsPerPage;
  const currentEmployees = filteredEmployees.slice(
    indexOfFirstEmployee,
    indexOfLastEmployee
  );
  const totalPages = Math.ceil(filteredEmployees.length / itemsPerPage);

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  return (
    <div className="manager-add-project">
      <h2>Add Project</h2>
      {/* <input
        type="text"
        placeholder="Search by Employee ID"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="search-bar"
      /> */}
      <div className="search-bar-container">
        <input
          type="text"
          className="search-bar"
          placeholder="Search by Employee ID..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <span className="search-icon">🔍</span> {/* Simple search icon */}
      </div>

      <div className="cards-container">
        {currentEmployees.map((employee, index) => (
          <div className="card" key={employee.emp_id}>
            <h3>Employee ID: {employee.emp_id}</h3>
            <p>
              <strong>Name:</strong> {employee.emp_name}
            </p>
            <p>
              <strong>Project Status:</strong> {getProjectName(employee.emp_id)}
            </p>
            <button
              className="adding-pro"
              onClick={() => handleOpenPopup(employee.emp_id)}
            >
              Add Project
            </button>
          </div>
        ))}
      </div>
      <div className="pagination-buttons">
        <button onClick={handlePrevPage} disabled={currentPage === 1}>
          Previous
        </button>
        {/* <span>
          Page {currentPage} of {totalPages}
        </span> */}
        <button onClick={handleNextPage} disabled={currentPage === totalPages}>
          Next
        </button>
      </div>

      {showPopup && (
        <div className="popup">
          <div className="popup-content">
            <h3>Add Project for Employee ID: {selectedEmpId}</h3>
            <form>
              <label>
                Project Name:
                <input
                  type="text"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  required
                />
              </label>
              {/* <button
                type="button"
                className="submit-button"
                onClick={handleAddProject}
              >
                Submit
              </button>
              <button
                className="cancel-button"
                type="button"
                onClick={closePopup}
              >
                Cancel
              </button> */}
              <div className="button-group">
                <button
                  type="button"
                  className="submit-button"
                  onClick={handleAddProject}
                >
                  Submit
                </button>
                <button
                  className="cancel-button"
                  type="button"
                  onClick={closePopup}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManagerAddProject;
