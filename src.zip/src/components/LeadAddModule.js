import React, { useState, useEffect } from "react";
import axios from "axios";
import "./LeadAddModule.css";

axios.defaults.baseURL = "http://localhost:8000"; // Backend URL

const LeadAddModule = () => {
  document.title = "Lead | Add Module";
  const [employees, setEmployees] = useState([]);
  const [projects, setProjects] = useState([]);
  const [modules, setModules] = useState([]);
  const [filteredEmployees, setFilteredEmployees] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedEmpId, setSelectedEmpId] = useState("");
  const [moduleName, setModuleName] = useState("");
  const [showPopup, setShowPopup] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6; // For 2 rows x 3 columns

  useEffect(() => {
    // Fetch employees data
    axios
      .get("/api/employees/")
      .then((response) => {
        setEmployees(response.data);
        setFilteredEmployees(response.data);
      })
      .catch((error) => {
        console.error("Error fetching employees:", error);
      });

    // Fetch projects data
    axios
      .get("/api/projects/")
      .then((response) => {
        setProjects(response.data);
      })
      .catch((error) => {
        console.error("Error fetching projects:", error);
      });

    // Fetch modules data
    axios
      .get("/api/modules/")
      .then((response) => {
        setModules(response.data);
      })
      .catch((error) => {
        console.error("Error fetching modules:", error);
      });
  }, []);

  useEffect(() => {
    setFilteredEmployees(
      employees.filter((employee) =>
        employee.emp_id.toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
    setCurrentPage(1);
  }, [searchTerm, employees]);

  const handleAddModule = () => {
    const data = {
      emp_id: selectedEmpId,
      module_name: moduleName,
    };

    axios
      .post("/api/modules/", data, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        alert("Module added successfully!");
        closePopup();
      })
      .catch((error) => {
        console.error("Error adding module:", error);
        alert("Failed to add module. Please try again.");
      });
  };

  const closePopup = () => {
    setShowPopup(false);
    setSelectedEmpId("");
    setModuleName("");
  };

  const getProjectName = (empId) => {
    const project = projects.find((project) => project.employee_id === empId);
    return project ? project.project_name : "Not Assigned";
  };

  const getModuleName = (empId) => {
    const module = modules.find((module) => module.emp_id === empId);
    return module ? module.module_name : "Not Assigned";
  };

  const handleOpenPopup = (empId) => {
    const projectName = getProjectName(empId);

    if (projectName === "Not Assigned") {
      alert("Can't assign module for this employee");
      return;
    }

    // Check if the employee already has a module assigned
    const existingModule = modules.find((module) => module.emp_id === empId);

    if (existingModule) {
      alert("Module already assigned to this employee");
      return;
    }

    setSelectedEmpId(empId);
    setShowPopup(true);
  };

  // Pagination logic
  const indexOfLastEmployee = currentPage * itemsPerPage;
  const indexOfFirstEmployee = indexOfLastEmployee - itemsPerPage;
  const currentEmployees = filteredEmployees.slice(
    indexOfFirstEmployee,
    indexOfLastEmployee
  );
  const totalPages = Math.ceil(filteredEmployees.length / itemsPerPage);

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  return (
    <div className="lead-add-module">
      <h2>Add Module</h2>
      {/* <input
        type="text"
        placeholder="Search by Employee ID"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="search-bar"
      /> */}
      <div className="search-bar-container">
        <input
          type="text"
          className="search-bar"
          placeholder="Search by Employee ID..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <span className="search-icon">🔍</span> {/* Simple search icon */}
      </div>

      <div className="cards-container">
        {currentEmployees.map((employee) => (
          <div className="card" key={employee.emp_id}>
            <h3>Employee ID: {employee.emp_id}</h3>
            <p>
              <strong>Name:</strong> {employee.emp_name}
            </p>
            <p>
              <strong>Project:</strong> {getProjectName(employee.emp_id)}
            </p>
            <p>
              <strong>Module:</strong> {getModuleName(employee.emp_id)}
            </p>
            <button
              className="add-module-btn"
              onClick={() => handleOpenPopup(employee.emp_id)}
            >
              Add Module
            </button>
          </div>
        ))}
      </div>
      <div className="pagination-buttons">
        <button onClick={handlePrevPage} disabled={currentPage === 1}>
          Previous
        </button>
        {/* <span>
          Page {currentPage} of {totalPages}
        </span> */}
        <button onClick={handleNextPage} disabled={currentPage === totalPages}>
          Next
        </button>
      </div>

      {showPopup && (
        <div className="popup">
          <div className="popup-content">
            <h3>
              Add Module for Employee ID: {selectedEmpId} (Project:{" "}
              {getProjectName(selectedEmpId)})
            </h3>
            <form>
              <label>
                Module Name:
                <input
                  type="text"
                  value={moduleName}
                  onChange={(e) => setModuleName(e.target.value)}
                  required
                />
              </label>
              <div className="button-group">
                <button
                  type="button"
                  className="submit-button"
                  onClick={handleAddModule}
                >
                  Submit
                </button>
                <button
                  className="cancel-button"
                  type="button"
                  onClick={closePopup}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default LeadAddModule;
