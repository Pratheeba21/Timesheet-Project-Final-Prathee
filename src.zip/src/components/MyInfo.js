// src/components/MyInfo.js
import React, { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import "./MyInfo.css";

const MyInfo = () => {
  const [employee, setEmployee] = useState(null);
  const { empId } = useAuth(); // Retrieve employee ID from context

  useEffect(() => {
    const fetchEmployeeDetails = async () => {
      try {
        const response = await fetch(
          `http://127.0.0.1:8000/api/employee-details/${empId}/`
        );
        if (response.ok) {
          const employeeData = await response.json();
          setEmployee(employeeData);
        } else {
          console.error("Error fetching employee details", response);
          alert("Error fetching employee details");
        }
      } catch (error) {
        console.error("Error fetching employee details", error);
        alert("Error fetching employee details");
      }
    };

    if (empId) {
      fetchEmployeeDetails();
    } else {
      alert("Employee ID not found");
    }
  }, [empId]);

  return (
    <div className="myinfo-container">
      <div className="myinfo-content">
        <h1>My Information</h1>
        {employee ? (
          <div className="employee-details">
            <p>
              <strong>Name:</strong> {employee.emp_name}
            </p>
            <p>
              <strong>Employee ID:</strong> {employee.emp_id}
            </p>
            <p>
              <strong>Department:</strong> {employee.department}
            </p>
            <p>
              <strong>Joining Date:</strong>{" "}
              {new Date(employee.joining_date).toLocaleDateString()}
            </p>
            <p>
              <strong>Position:</strong> {employee.position}
            </p>
          </div>
        ) : (
          <p>Loading...</p>
        )}
      </div>
    </div>
  );
};

export default MyInfo;
