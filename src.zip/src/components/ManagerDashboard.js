import React, { useState, useEffect } from "react";
import ManagerSidebar from "./ManagerSidebar";
import ManagerHome from "./ManagerHome";
import ManagerPage from "./ManagerPage";
import ManagerAddProject from "./ManagerAddProject";
import EmployeeInfo from "./EmployeeInfo"; // Import EmployeeInfo
import "./ManagerDashboard.css";

const ManagerDashboard = () => {
  document.title = "Dashboard | Manager";

  // Retrieve the active component from localStorage, default to "home"
  const [activeComponent, setActiveComponent] = useState(() => {
    return localStorage.getItem("managerActiveComponent") || "home";
  });

  // Save the active component to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("managerActiveComponent", activeComponent);
  }, [activeComponent]);

  const renderContent = () => {
    switch (activeComponent) {
      case "home":
        return <ManagerHome />;
      case "view-timesheet":
        return <ManagerPage />;
      case "add-project":
        return <ManagerAddProject />;
      case "employee-info": // New case for EmployeeInfo
        return <EmployeeInfo />;
      default:
        return <ManagerHome />; // Default to ManagerHome if the activeComponent is not recognized
    }
  };

  return (
    <div className="manager-dashboard">
      <ManagerSidebar setActiveComponent={setActiveComponent} />
      <div className="manager-content">{renderContent()}</div>
    </div>
  );
};

export default ManagerDashboard;
