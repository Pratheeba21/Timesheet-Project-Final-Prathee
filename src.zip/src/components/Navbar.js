// src/components/Navbar.js
import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
    return (
        <nav className="navbar">
            <div className="navbar-container">
                <Link to="/" className="navbar-brand">MyApp</Link>
                <ul className="navbar-menu">
                    <li><Link to="/dashboard">Dashboard</Link></li>
                    <li><Link to="/update-timesheet">Update Timesheet</Link></li>
                    <li><Link to="/view-timesheet">View Timesheet</Link></li>
                </ul>
            </div>
        </nav>
    );
};

export default Navbar;
