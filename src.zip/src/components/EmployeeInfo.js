import React, { useState, useEffect } from "react";
import "./EmployeeInfo.css";
import axios from "axios";

const EmployeeInfo = () => {
  document.title = "EmployeeInfo";
  const [employees, setEmployees] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const employeesPerPage = 20;

  useEffect(() => {
    // Fetch employee details from the API
    axios
      .get("http://127.0.0.1:8000/api/employee-details/")
      .then((response) => {
        setEmployees(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the employee data!", error);
      });
  }, []);

  // Handle search input change
  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  // Filter employees based on search query
  const filteredEmployees = employees.filter((employee) =>
    employee.emp_id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Calculate the indexes of the employees to be shown on the current page
  const indexOfLastEmployee = currentPage * employeesPerPage;
  const indexOfFirstEmployee = indexOfLastEmployee - employeesPerPage;
  const currentEmployees = filteredEmployees.slice(
    indexOfFirstEmployee,
    indexOfLastEmployee
  );

  // Handle page changes
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  const handleBoxClick = (employee) => {
    setSelectedEmployee(employee);
  };

  const closePopup = () => {
    setSelectedEmployee(null);
  };

  // Function to display "Not Assigned" for null values
  const displayValue = (value) => {
    return value ? value : "Not Assigned";
  };

  return (
    <div className="employee-info-container">
      <h2>Employee Information</h2>
      <div className="search-bar-container">
        <input
          type="text"
          className="search-bar"
          placeholder="Search by Employee ID..."
          value={searchQuery}
          onChange={handleSearchChange}
        />
        <span className="search-icon">🔍</span> {/* Simple search icon */}
      </div>

      <div className="employee-boxes">
        {currentEmployees.map((employee) => (
          <div
            key={employee.emp_id}
            className="employee-box"
            onClick={() => handleBoxClick(employee)}
          >
            <span>{employee.emp_id}</span>
          </div>
        ))}
      </div>
      <div className="pagination">
        <button
          onClick={() => paginate(currentPage - 1)}
          disabled={currentPage === 1}
        >
          Previous
        </button>
        <button
          onClick={() => paginate(currentPage + 1)}
          disabled={indexOfLastEmployee >= filteredEmployees.length}
        >
          Next
        </button>
      </div>

      {/* <div className="pagination">
        <button
          onClick={() => paginate(currentPage - 1)}
          disabled={currentPage === 1}
        >
          Previous
        </button>
        <button
          onClick={() => paginate(currentPage + 1)}
          disabled={indexOfLastEmployee >= filteredEmployees.length}
        >
          Next
        </button>
      </div> */}

      {selectedEmployee && (
        <div className="employee-popup">
          <div className="employee-popup-content">
            <span className="close-popup" onClick={closePopup}>
              &times;
            </span>
            <h3>Employee Details</h3>
            <p>
              <strong>Name:</strong> {selectedEmployee.emp_name}
            </p>
            <p>
              <strong>Email:</strong> {selectedEmployee.email_id}
            </p>
            <p>
              <strong>Joining Date:</strong> {selectedEmployee.joining_date}
            </p>
            <p>
              <strong>Project Name:</strong>{" "}
              {displayValue(selectedEmployee.project_name)}
            </p>
            <p>
              <strong>Module Name:</strong>{" "}
              {displayValue(selectedEmployee.project_module)}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeeInfo;
