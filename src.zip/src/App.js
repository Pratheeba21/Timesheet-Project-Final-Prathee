import React from "react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
  useLocation,
} from "react-router-dom";
import Dashboard from "./components/Dashboard";
import UpdateTimesheet from "./components/UpdateTimesheet";
import ViewTimesheet from "./components/ViewTimesheet";
import Login from "./components/Login";
import LeadDashboard from "./components/LeadDashboard";
import EmployeeDetail from "./components/EmployeeDetails";
import ManagerDashboard from "./components/ManagerDashboard";
import ManagerAddProject from "./components/ManagerAddProject";
import LeadAddModule from "./components/LeadAddModule";
import Sidebar from "./components/Sidebar";
import HRDashboard from "./components/HRDashboard";
import EmployeeTimesheetDetails from "./components/EmployeeTimesheetDetails";
import { AuthProvider, useAuth } from "./context/AuthContext";
import "./App.css";

const App = () => {
  return (
    <AuthProvider>
      <Router>
        <div className="app">
          <Content />
        </div>
      </Router>
    </AuthProvider>
  );
};

const Content = () => {
  const { empId } = useAuth();
  const location = useLocation();

  // Only show the sidebar for employee-specific routes
  const showSidebar =
    empId &&
    ["/dashboard", "/update-timesheet", "/view-timesheet", "/employee-details"].includes(
      location.pathname
    );

  return (
    <>
      {showSidebar && <Sidebar />}
      <div className={showSidebar ? "content" : ""}>
        <Routes>
          <Route path="/" element={<Navigate to={empId ? "/dashboard" : "/login"} />} />
          <Route path="/login" element={<Login />} />
          {empId && (
            <>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/update-timesheet" element={<UpdateTimesheet />} />
              <Route path="/view-timesheet" element={<ViewTimesheet />} />
              <Route path="/lead/*" element={<LeadDashboard />} />
              <Route path="/manager/*" element={<ManagerDashboard />} />
              <Route path="/manager-add-project" element={<ManagerAddProject />} />
              <Route path="/hr/*" element={<HRDashboard />} />
              <Route path="/employee-detail" element={<EmployeeDetail />} />
              <Route path="/employee-details/:empId" element={<EmployeeTimesheetDetails />} />
            </>
          )}
          <Route path="*" element={<Navigate to={empId ? "/dashboard" : "/login"} />} />
        </Routes>
      </div>
    </>
  );
};

export default App;
