# serializers.py

from rest_framework import serializers
from .models import Employee, Timesheet, Project, Module
from django.contrib.auth.hashers import make_password

class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = '__all__'

class EmployeeListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = ['emp_id', 'emp_name']

class TimesheetSerializer(serializers.ModelSerializer):
    emp_id = serializers.CharField(source='emp.emp_id', read_only=True)
    emp_name = serializers.CharField(source='emp.emp_name', read_only=True)
    emp = serializers.PrimaryKeyRelatedField(queryset=Employee.objects.all(), write_only=True)
    project_name = serializers.CharField(read_only=True)
    project_module = serializers.CharField(read_only=True)

    class Meta:
        model = Timesheet
        fields = ['id', 'emp', 'emp_id', 'emp_name', 'date', 'project_name', 'project_module', 'start_time', 'end_time', 'comments', 'total_hours', 'lead_approval', 'manager_approval', 'timestamp']

class ProjectSerializer(serializers.ModelSerializer):
    emp_id = serializers.CharField(write_only=True)
    employee_id = serializers.CharField(source='emp.emp_id', read_only=True)

    class Meta:
        model = Project
        fields = ['emp_id', 'employee_id', 'project_name']  # Note: removed module_name

    def create(self, validated_data):
        emp_id = validated_data.pop('emp_id')
        try:
            employee = Employee.objects.get(emp_id=emp_id)
        except Employee.DoesNotExist:
            raise serializers.ValidationError({"emp_id": "Employee with this ID does not exist."})

        project = Project.objects.create(emp=employee, **validated_data)
        return project



class ModuleSerializer(serializers.ModelSerializer):
    emp_id = serializers.PrimaryKeyRelatedField(queryset=Employee.objects.all(), source='emp')
    emp_name = serializers.CharField(source='emp.emp_name', read_only=True)
    module_name = serializers.CharField(max_length=255)

    class Meta:
        model = Module
        fields = ['emp_id', 'emp_name', 'module_name']



from rest_framework import serializers
from .models import Employee, Timesheet

class EmployeeDetailWithProjectAndModuleSerializer(serializers.ModelSerializer):
    project_name = serializers.SerializerMethodField()
    project_module = serializers.SerializerMethodField()

    class Meta:
        model = Employee
        fields = ['emp_id', 'emp_name', 'email_id', 'joining_date', 'project_name', 'project_module']

    def get_project_name(self, obj):
        # Assuming a single project per employee for simplicity; adjust if multiple projects are possible.
        timesheet = Timesheet.objects.filter(emp=obj).first()
        if timesheet:
            return timesheet.project_name
        return None

    def get_project_module(self, obj):
        # Assuming a single module per employee for simplicity; adjust if multiple modules are possible.
        timesheet = Timesheet.objects.filter(emp=obj).first()
        if timesheet:
            return timesheet.project_module
        return None
