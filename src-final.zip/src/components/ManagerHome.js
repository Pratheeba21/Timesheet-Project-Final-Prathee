import React from "react";
import styled from "styled-components";
import { useAuth } from "../context/AuthContext";

// Styled components
const Container = styled.div`
  padding: 25px;
  background-color: #021526;
  min-height: 100vh;
  display: flex;
  justify-content: center; /* Center horizontally */
  align-items: flex-start; /* Align items towards the top */
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  margin-left: 0; /* Adjust this value to control the left margin */
`;

const Content = styled.div`
  text-align: center;
  width: 400px;
  background-color: #06335a; /* Dark background for content */
  border-radius: 15px;
  box-shadow: 0px 0px 20px 5px rgba(80, 140, 155, 0.7); /* Bright blue glow */
  padding: 30px;
  margin-top: 150px; /* Position 150px from the top */
  position: relative;
  // animation: dance 5s ease-in-out infinite; 
  /* Smooth dancing animation */
  overflow: hidden;

  &::before {
    content: "";
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(
      circle at center,
      rgba(80, 140, 155, 0.8),
      transparent 70%
    );
    transform: rotate(45deg);
    animation: float-shine 6s ease-in-out infinite;
    pointer-events: none; /* Allow interactions with the content */
  }
`;

const Heading = styled.h2`
  color: #00d1ff; /* Brighter blue for headings */
  font-size: 2.5em;
  margin-bottom: 20px;
`;

const Paragraph = styled.p`
  color: #b0e0e6; /* Light blue for regular text */
  font-size: 1.2em;
  margin: 10px 0;

  strong {
    color: #ffffff; /* White for emphasized text */
    font-weight: bold;
  }
`;

const ManagerHome = () => {
  const { empId } = useAuth();

  return (
    <Container>
      <Content>
        <Heading>Welcome, Manager</Heading>
        <Paragraph>User ID: {empId}</Paragraph>
        <Paragraph>We're glad to have you here!</Paragraph>
      </Content>
    </Container>
  );
};

export default ManagerHome;
